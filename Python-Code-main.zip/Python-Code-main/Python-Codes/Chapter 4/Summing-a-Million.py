numbers = list(range(1, 1_000_001))

print(min(numbers))   # 1
print(max(numbers))   # 1000000
print(sum(numbers))   # 500000500000
