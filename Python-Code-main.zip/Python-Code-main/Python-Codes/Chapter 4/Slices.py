foods = ['pizza', 'falafel', 'carrot cake', 'cannoli', 'ice cream']

print("The first three items in the list are:", foods[:3])
print("Three items from the middle of the list are:", foods[1:4])
print("The last three items in the list are:", foods[-3:])
