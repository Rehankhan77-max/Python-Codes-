odd_numbers = list(range(1, 21, 2))
for odd in odd_numbers:
    print(odd)
