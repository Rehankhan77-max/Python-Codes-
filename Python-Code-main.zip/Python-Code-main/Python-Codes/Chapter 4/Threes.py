threes = list(range(3, 31, 3))
for num in threes:
    print(num)
