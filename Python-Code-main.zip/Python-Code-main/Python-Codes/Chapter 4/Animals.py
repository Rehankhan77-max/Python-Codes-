animals = ['dog', 'cat', 'elephant']
for animal in animals:
    print(animal)
