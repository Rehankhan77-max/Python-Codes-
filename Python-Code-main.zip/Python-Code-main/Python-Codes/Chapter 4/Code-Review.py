pizzas = ['margherita', 'pepperoni', 'hawaiian']
for pizza in pizzas:
    print(pizza)
