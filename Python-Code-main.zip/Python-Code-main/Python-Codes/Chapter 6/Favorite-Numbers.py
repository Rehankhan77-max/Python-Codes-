favorite_numbers = {
    'alice': 3,
    'bob': 7,
    'carol': 5
}
for name, number in favorite_numbers.items():
    print(f"{name.title()}'s favorite number is {number}.")

