def show_magicians(names):
    """Print each magician's name."""
    for name in names:
        print(name)

magicians = ['alice', 'bob', 'carol']
show_magicians(magicians)
