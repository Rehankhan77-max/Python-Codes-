def favorite_book(title):
    """Print a favorite book message."""
    print(f"One of my favorite books is '{title.title()}'.")

# Example call
favorite_book('alice in wonderland')
