def make_shirt(size, message):
    """Describe a T-shirt size and printed message."""
    print(f"Shirt size: {size}, Message: '{message}'.")

# Example call
make_shirt('M', 'Hello World')
