def display_message():
    """Display a message about what I'm learning."""
    print("I'm learning about functions in Python!")

# Call the function
display_message()
