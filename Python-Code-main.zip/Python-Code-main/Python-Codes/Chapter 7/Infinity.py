# WARNING: This loop is infinite. Use Ctrl+C to interrupt.
while True:
    print("I love Python!")
