car = input("What kind of rental car would you like? ")
print(f"Let me see if I can find you a {car}.")
