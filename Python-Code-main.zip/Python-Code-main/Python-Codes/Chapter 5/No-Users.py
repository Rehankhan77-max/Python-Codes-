usernames = []

if usernames:
    for user in usernames:
        print(f"Hello {user}")
else:
    print("We need to find some users!")
