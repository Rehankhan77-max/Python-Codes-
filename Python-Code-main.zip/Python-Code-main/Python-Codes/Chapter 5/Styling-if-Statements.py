# Correctly styled conditional
age = 25
if age >= 18:
    print("You are an adult.")
else:
    print("You are a minor.")
