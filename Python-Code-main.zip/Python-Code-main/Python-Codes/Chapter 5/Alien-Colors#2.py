alien_color = 'yellow'
if alien_color == 'green':
    print("You earned 5 points.")
else:
    print("You earned 10 points.")
