car = 'subaru'
print("Is car == 'subaru'? I predict True.")
print(car == 'subaru')

print("Is car == 'audi'? I predict False.")
print(car == 'audi')

name = "Alice"
print(name.lower() == "alice")   # True
print(name == "alice")           # False

age = 20
print(age > 18)                  # True
print(age < 18)                  # False
print(age >= 20 and age < 30)    # True
print(age == 21 or age == 20)    # True
